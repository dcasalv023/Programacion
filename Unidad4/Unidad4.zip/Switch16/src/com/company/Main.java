//Realiza un programa que nos diga si hay probabilidad de que nuestra pareja
//nos está siendo infiel. El programa irá haciendo preguntas que el usuario
//contestará con verdadero o falso. Cada pregunta contestada como verdadero
//sumará 3 puntos. Las preguntas contestadas con falso no suman puntos. Utiliza el fichero test_infidelidad.txt para obtener las preguntas y las conclusiones
//del programa.
package com.company;

import java.util.Scanner;

public class Main {

    public static void main(String[] args) {
        Scanner reader = new Scanner(System.in);
    }
}